<?php # **************************** AYM EASY SITE V: 5.1 ********************
# FORMULARIO PARA AGREGAR sds
# AYMSOFT SAS
# Saturday 17th of May 2014 10:45:38 AM


?>

<form action="/aymsite/actionsdsdd" method="post" name="frm_add_sdsdd" id="frm_add_sdsdd" enctype="multipart/form-data">
	<fieldset class="aym_frm_content">
		
		<div class="aym_clear"></div>
		<div class="aym_frm_two_col">
			<span class="aym_col_1">nombre1</span> 
			<span class="aym_col_2"><input name="sds" type="text" class="input_texbox" id="sds"/></span>
		</div>
		<div class="aym_clear"></div> 
		<div class="aym_frm_two_col">
			<div class="aym_col_1">&nbsp;</div>
			<div class="aym_col_2"><input type="submit" value="Aceptar" class=""/> 
				<input name="action" type="hidden" id="action" value="sdsdsd" />
			</div>
			<div class="aym_clear"></div>
		</div>
    </fieldset>
</form>
<div class="aym_separator"></div>
<div class="aym_index_message">Todos los campos son obligatorios</div>